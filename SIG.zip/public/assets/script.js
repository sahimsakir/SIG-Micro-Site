var cards = document.querySelectorAll('.card');

[...cards].forEach((card)=>{
  card.addEventListener( 'click', function() {
    card.classList.toggle('is-flipped');
  });
});
var main = document.querySelector('.main-circle');
var main_bg = document.querySelector('.menu-bg');
var details = document.querySelector('.details');
var head1 = document.querySelector('.header');
var head2 = document.querySelector('.section-header1');
var para1 = document.querySelector('.paragraph1');
var head3 = document.querySelector('.section-header2');
var para2 = document.querySelector('.paragraph2');
var nb = document.querySelector('.nav-button');
var i = 0;
var leftArrow = document.querySelector('.left-arrow');
var rightArrow = document.querySelector('.right-arrow');
var mainHome = document.querySelector('.main-home');

function showHome() {

  main.classList.remove('act1','act2', 'act3', 'act4', 'act5');
  main_bg.classList.remove('act1', 'act2', 'act3', 'act4', 'act5');
  details.classList.remove('act1', 'act2', 'act3', 'act4', 'act5');
  main.classList.toggle('active');
  main_bg.classList.toggle('active')
  nb.classList.remove('active');
  
}

function showRight() {
  i = i + 1;

  if(i==1) {
    return showContent1();
    
  }
    
  else if (i==2){
    return showContent2();
  } 
    
  else if (i==3){
    return showContent3();
  } 
    
  else if (i==4) {
    return showContent4();
  }
  else if (i==5)
  {

    return showContent5();
  } 
    
  else
    {
      i=5;
    }
}
function showLeft() {
  i = i - 1;
  if(i==1) {
    return showContent1();
    
  }
    
  else if (i==2){
    return showContent2();
  } 
    
  else if (i==3){
    return showContent3();
  } 
    
  else if (i==4) {
    return showContent4();
  }
  else if (i==5)
  {
    return showContent5();
  } 
  else
    {
      i=1;
    }
    
}


function showContent1() {
  main.classList.remove('act2','act3', 'act4', 'act5', 'active');
  main_bg.classList.remove('act2','act3', 'act4', 'act5', 'active');
  details.classList.remove('act2','act3', 'act4', 'act5', 'active');
  details.classList.toggle('act1');
  main.classList.toggle('act1');
  main_bg.classList.toggle('act1');
  nb.classList.add('active');
  leftArrow.setAttribute('src','assets/images/left-arrow-light.png');
  rightArrow.setAttribute('src','assets/images/right-arrow.png');
}
function showContent2() {
  main.classList.remove('act1', 'act3', 'act4', 'act5', 'active');
  main_bg.classList.remove('act1', 'act3', 'act4', 'act5', 'active')
  details.classList.remove('act1', 'act3', 'act4', 'act5', 'active');
  details.classList.toggle('act2');
  main.classList.toggle('act2');
  main_bg.classList.toggle('act2');
  nb.classList.add('active');
  leftArrow.setAttribute('src','assets/images/left-arrow.png');
  rightArrow.setAttribute('src','assets/images/right-arrow.png')
}
function showContent3() {
  main.classList.remove('act2','act1', 'act4', 'act5', 'active');
  main_bg.classList.remove('act2','act1', 'act4', 'act5', 'active');
  details.classList.remove('act2','act1', 'act4', 'act5', 'active');
  details.classList.toggle('act3');
  main.classList.toggle('act3');
  main_bg.classList.toggle('act3');
  nb.classList.add('active');
  leftArrow.setAttribute('src','assets/images/left-arrow.png');
  rightArrow.setAttribute('src','assets/images/right-arrow.png')

}
function showContent4() {
  main.classList.remove('act1','act2', 'act3', 'act5', 'active');
  main_bg.classList.remove('act1','act2', 'act3', 'act5', 'active');
  details.classList.remove('act1','act2', 'act3', 'act5', 'active');
  details.classList.toggle('act4');
  main.classList.toggle('act4');
  main_bg.classList.toggle('act4');
  nb.classList.add('active');
  leftArrow.setAttribute('src','assets/images/left-arrow.png');
  rightArrow.setAttribute('src','assets/images/right-arrow.png'); 
}
function showContent5() {
  main.classList.remove('act1','act2', 'act3', 'act4', 'active');
  main_bg.classList.remove('act1','act2', 'act3', 'act4', 'active');
  details.classList.remove('act1','act2', 'act3', 'act4', 'active');
  details.classList.toggle('act5');
  main.classList.toggle('act5');
  main_bg.classList.toggle('act5');
  nb.classList.add('active');
  leftArrow.setAttribute('src','assets/images/left-arrow.png');
  rightArrow.setAttribute('src','assets/images/right-arrow-light.png');
}

